---
name: Executive & Operational SaaS Portal
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2151da'
  primary: '#0037b0'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#004f35'
  on-tertiary: '#ffffff'
  tertiary-container: '#006948'
  on-tertiary-container: '#76eab6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b5'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets high-growth enterprise software teams, executive leadership, and internal workforce members who require clarity, speed, and absolute operational reliability. The aesthetic establishes immediate trust, clarity, and authority while remaining modern, airy, and agile. 

The aesthetic is **Corporate Modern Refined**: crisp geometry, meticulous alignment, purposeful white space, and subtle depth layers that prevent visual fatigue during long work sessions. It balances high-density data visualizations for founders and executives with distraction-free, actionable workspaces for everyday team members. Interfaces must feel composed, responsive, and impeccably organized.

## Colors

The palette emphasizes clarity, institutional dependability, and high contrast for rapid scanning:

- **Primary (`#1D4ED8`)**: Royal blue drives intentional interactions, focal calls-to-action, navigation selection, and active executive focus states.
- **Secondary (`#0F172A`)**: Deep obsidian slate anchors structural typography, high-priority dashboard metric titles, and solid iconography.
- **Tertiary (`#059669`)**: Emerald green represents successful operational states, active attendance, system health, and affirmative trends.
- **Neutral (`#64748B`)**: Balanced slate manages secondary metadata, breadcrumbs, muted table labels, and inactive utility icons.

### Semantic Status Colors
- **Success / Active (`#059669`)**: Present status, healthy system states, completed milestones. Light background tint: `#ECFDF5`. Border: `#A7F3D0`.
- **Warning / Pending (`#D97706`)**: Late check-ins, awaiting approvals, non-blocking sync warnings. Light background tint: `#FFFBEB`. Border: `#FDE68A`.
- **Destructive / Urgent (`#E11D48`)**: Absent statuses, failed deployments, immediate escalations. Light background tint: `#FFF1F2`. Border: `#FECDD3`.

### Backgrounds & Borders
- **Canvas Base**: `#F8FAFC` provides a calm, cool-tinted resting foundation.
- **Surface Elevation**: `#FFFFFF` pure white separates interactable cards, modals, side drawers, and navigation bars from the canvas.
- **Structural Dividers & Borders**: `#E2E8F0` defines cards, data grid rows, and segmented controls with subtle, razor-sharp fidelity.

## Typography

The type scale combines **Plus Jakarta Sans** for expressive, polished geometric headers with **Inter** for neutral, utilitarian dense body copy and analytical data layouts. 

- **Headlines & Metric Titles**: Rendered in Plus Jakarta Sans with negative tracking to convey a tailored, modern SaaS aesthetic.
- **Data Tables, Monitored Outputs & Body**: Rendered in Inter with proportional tabular figures enabled (`font-variant-numeric: tabular-nums`) for clean vertical scanning across KPI tiles, monetary figures, timestamps, and progress tables.
- **Labels & Micro-copy**: Set in Inter Medium and Semi-Bold with slight positive letter spacing to maintain legibility in compact pill badges, table headers, and status flags.

## Layout & Spacing

The portal relies on a 12-column fluid grid system anchored by strict structural gutters and a responsive outer frame.

- **Desktop (1280px+)**: 12-column layout with `gutter-lg` (2rem) and `margin-lg` (3rem). Multi-column dashboard widgets (e.g. 4-column metric cards, 8-column primary timeline view) sit side by side.
- **Tablet (768px - 1279px)**: 8-column layout with `gutter` (1.5rem) and `margin` (2rem). Secondary panels collapse into swipeable tabs or stacked rows.
- **Mobile (< 768px)**: 4-column layout with `gutter-sm` (1rem) and `margin-sm` (1rem). Executive summary tiles compress to vertical single-column card flows with horizontally scrollable metric bars.

Spacing inside components follows an 8pt base grid for structural layout spacing, paired with a 4pt subgrid strictly for compact form controls, inline badges, and table line heights.

## Elevation & Depth

This system avoids heavy shadows, using a combination of **low-contrast slate outlines** (`#E2E8F0`) and **ambient diffused elevation layers** tinted with cool slate:

- **Level 0 (Flat Canvas)**: `#F8FAFC`. Background for core layout zones, breadcrumb trays, and peripheral sidebars.
- **Level 1 (Resting Cards & Grids)**: Background `#FFFFFF`, border `1px solid #E2E8F0`, shadow `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hovered Cards & Interactive Modules)**: Background `#FFFFFF`, border `1px solid #CBD5E1`, shadow `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Dropdown Menus & Popovers)**: Background `#FFFFFF`, border `1px solid #E2E8F0`, shadow `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`.
- **Level 4 (Modals, Overlays & Drawers)**: Background `#FFFFFF`, shadow `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`. Canvas backdrop overlay uses `#0F172A` at 40% opacity with a `4px` backdrop blur.

## Shapes

The interface balances sharp enterprise structure with approachable softness via an intentional corner radius hierarchy:

- **Base Elements (`0.5rem` / 8px)**: Standard buttons, text input fields, dropdown triggers, and interactive cards.
- **Containers & Modals (`rounded-lg` / 1rem / 16px)**: Executive dashboard KPI containers, data tables, contextual drawers, and modal windows.
- **Feature Sections (`rounded-xl` / 1.5rem / 24px)**: Hero onboarding banners and top-level profile summaries.
- **Pill Elements (`9999px`)**: Status tags, category indicators, employee presence badges, and avatar frames are strictly pill-shaped to stand out against structural rectangular cards.

## Components

### Buttons
- **Primary**: Background `#1D4ED8`, text `#FFFFFF`, border none, border-radius `0.5rem`. Hover: `#1E40AF`. Active: scale `0.98` with background `#1E3A8A`.
- **Secondary / Outline**: Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`. Hover: background `#F8FAFC`, border `#CBD5E1`.
- **Ghost**: Background transparent, text `#64748B`. Hover: background `#F1F5F9`, text `#0F172A`.

### Status Indicators & Pill Tags
- **Base Style**: Height `24px`, padding `0 10px`, border-radius `9999px`, font-size `0.75rem`, font-weight `600`, inline-flex alignment.
- **Active / Present**: Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`. Includes a centered 6px pulsating circular dot in `#059669`.
- **Pending / Late**: Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`.
- **Absent / Urgent**: Background `#FFF1F2`, text `#9F1239`, border `1px solid #FECDD3`.

### Input Fields & Controls
- **Text Inputs**: Height `40px`, padding `0 12px`, border `1px solid #E2E8F0`, background `#FFFFFF`, border-radius `0.5rem`. Placeholder text `#94A3B8`.
- **Focus State**: Border `#1D4ED8` with a `0 0 0 3px rgba(29, 78, 216, 0.12)` halo ring.
- **Checkboxes & Radios**: 18px square (checkbox) or circle (radio), border `1.5px solid #CBD5E1`. Selected state: `#1D4ED8` fill with crisp white glyph.

### Cards & Analytical Widgets
- **Standard Card**: White `#FFFFFF` surface, `1px solid #E2E8F0` border, `1rem` internal padding, `rounded-lg`.
- **Metric KPI Tile (Founder Dashboard)**: Displays subtle category label in `label-sm` (`#64748B`), large primary value in `headline-lg` (`#0F172A`), and trailing delta badge (e.g. green pill with `+14.2%`) aligned top-right.

### Data Tables & List Views
- **Header Rows**: Height `44px`, background `#F8FAFC`, border-bottom `1px solid #E2E8F0`, uppercase `label-xs` font with `#64748B` color.
- **Body Rows**: Height `56px`, background `#FFFFFF`, border-bottom `1px solid #F1F5F9`. Hover state transitions to `#F8FAFC` across 150ms.
- **Row Micro-interactions**: Trailing action icons (edit, context menu) remain muted at 40% opacity until row hover, maintaining a clutter-free visual plane.